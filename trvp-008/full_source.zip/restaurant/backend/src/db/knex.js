// src/db/knex.js
const knex = require('knex')({
  client: 'pg',  // Для PostgreSQL
  connection: {
    host: 'localhost',
    user: 'postgres',  // Убедись, что имя пользователя правильное
    password: '',  // Если есть пароль, укажи его
    database: 'restaurant',  // Название базы данных
  },
});

module.exports = knex;


const express = require('express');
const knex = require('../db/knex');
const router = express.Router();
const { getDishes, addDish } = require('../controllers/dishController');

// Получение всех блюд
router.get('/', getDishes);

// Добавление нового блюда
router.post('/', addDish);

module.exports = router;
